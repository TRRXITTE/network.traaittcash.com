var api = 'https://xtcashexplorer.trrxitte.com';
	var donationAddress = "cashKdCEq5U7W2QDS5ffMETf1smoKLBm3C1GMYvPdEVUU9LKr1uDFrLNPkmfKgzcTcB4ASsypziCeVQ5iqkzC7fZ1pDDLSxgZF";
	var blockTargetInterval = 144; // enter the block interval in seconds
	var coinUnits = 100000000;  // enter in the amount of atomic units in 1 coin, eg. 100 shells = 1 trtl
	var totalSupply =  8874400000000000; // enter the total supply in atomic units
	var symbol = 'XTCASH'; // enter the coin's ticker
	var refreshDelay = 30000;
	
	// pools stats by MainCoins
	var networkStat = {
	 "XTCASH": [
		[""]
	 ]
	};
	
	var networkStat2 = {
	    "XTCASH": [
		[""]
	 ]
	};
