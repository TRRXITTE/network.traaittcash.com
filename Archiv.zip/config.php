<?php
return array(
        'api' => 'https://xtcashexplorer.trrxitte.com',
        'blockTargetInterval' => 144,
        'coinUnits' => 100
);
