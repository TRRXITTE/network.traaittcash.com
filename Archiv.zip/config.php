<?php
return array(
        'api' => 'https://europe-west.traaitt.com',
        'blockTargetInterval' => 144,
        'coinUnits' => 100
);
